/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package missaojava;

import java.util.Scanner;

/**
 *
 * @author vinicius
 */
public class Missao1Cadastro {
    
    public static void main(String[] args){
        
        String nome;
        int idade;
        String profissao;
        char sexo;
        String barra = "==========";

        Scanner entrada = new Scanner(System.in);

        System.out.println("Bem vindo a bordo!");

        System.out.println("Digite o seu nome: ");
        nome = entrada.next();

        System.out.println("Digite a sua idade: ");
        idade = entrada.nextInt();

        System.out.println("Digite a sua profissao: ");
        profissao = entrada.next();

        System.out.println("Digite seu sexo (M/F): ");
        sexo = entrada.next().charAt(0);
        
        System.out.println(barra);
        System.out.println("Nome: "+ nome);
        System.out.println("Idade: "+idade);
        System.out.println("Profissao: "+profissao);
        System.out.println("Sexo: "+sexo);
        
        entrada.close();
    
}
}
