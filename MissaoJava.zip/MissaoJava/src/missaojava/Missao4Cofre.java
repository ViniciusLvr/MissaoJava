/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package missaojava;

import java.util.Scanner;

/**
 *
 * @author vinicius
 */
public class Missao4Cofre {
    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        String barra = "==========";
        
        byte cofreScreto = 0;
        System.out.println(""+
                "Escolha uma opção:\n "+
                "1 - Faturas \n "+
                "2 - Saldo \n "+
                "3 - Emergencias \n"+
                "4 - Modo Ferias"
        );
        cofreScreto = entrada.nextByte();
        
        switch (cofreScreto) {
            case 1:
                System.out.println(barra);
                System.out.println("Faturas");
                break;
            case 2:
                System.out.println(barra);
                System.out.println("Saldo");
            case 3:
                System.out.println(barra);
                System.out.println("Emergencias");
                break;
            case 4:
                System.out.println(barra);
                System.out.println("Modo Ferias");
                break;
        }
    }
    
}
