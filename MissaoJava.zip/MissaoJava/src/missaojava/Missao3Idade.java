/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package missaojava;

import java.util.Scanner;

/**
 *
 * @author vinicius
 */
public class Missao3Idade {
    public static void main(String[] args) {
        
        String nome;
        int idade;
        String barra = "==========";
        Scanner entrada = new Scanner(System.in);

        System.out.println("Bem vindo a bordo!");
        
        System.out.println("Digite o seu nome: ");
        nome = entrada.next();

        System.out.println("Digite a sua idade: ");
        idade = entrada.nextInt();
        
        System.out.println(barra);
        
        if(idade>=18){
            System.out.println("Adulto");
        }
        else if(idade<18 && idade >=12){
            System.out.println("Adolescente");
        }
        else if(idade>=0 && idade<12){
            System.out.println("Criança");
        }
        else{
            System.out.println("Dados invalidos");
        }
        
        System.out.println("Nome: "+ nome);
        System.out.println("Idade: "+idade);
        
        entrada.close();
    }
    
}
