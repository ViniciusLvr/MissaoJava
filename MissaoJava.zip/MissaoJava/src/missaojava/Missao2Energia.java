/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package missaojava;

import java.util.Scanner;

/**
 *
 * @author vinicius
 */
public class Missao2Energia {
    
    public static void main(String[] args){
    
        float energia1;
        float energia2;
        
        
        String barra = "==========";
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Digite o primeiro valor de energia: ");
        energia1 = entrada.nextInt();
        
        System.out.println("Digite o segundo valor de energia: ");
        energia2 = entrada.nextInt();
        
        float media = (energia1 + energia2) / 2;
        float difAbsoluta = Math.abs(energia1 - energia2);
        
        System.out.println(barra);
        System.out.println("A media é: " + media + ". E a diferença absoluta é: "+ difAbsoluta + ".");
        
        if(difAbsoluta>=10){
            System.out.println("Situação: Estavél.");
        }
        else{
            System.out.println("Situação: Insegura.");
        }
        
        
        
    }
}
